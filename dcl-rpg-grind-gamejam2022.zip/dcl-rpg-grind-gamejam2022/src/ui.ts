import * as ui from '@dcl/ui-scene-utils'
 


export let HPBar : ui.UIBar
export let MPBar : ui.UIBar
export let breadLabel
export let orbLabel
export let expLabel
export let lvlLabel
export let killCountLabel
//export let canRewardURL: string = 'https://docs.decentraland.org';




export function buildUI() {

  let healthLabel = new ui.CornerLabel('HP:', -180, 495)
  
  HPBar = new ui.UIBar(1, -30, 500, Color4.Green(), ui.BarStyles.ROUNDSILVER, 1)
  

  let mpLabel = new ui.CornerLabel('MP:', -180, 445)
  MPBar = new ui.UIBar(1, -30, 450, Color4.Blue(), ui.BarStyles.ROUNDSILVER, 1)

  
  killCountLabel = new ui.UICounter(0, 0, 395, Color4.White(), 25, true)
  let killCountIcon = new ui.MediumIcon('models/ui/droid.png', -70, 385)
  
  let breadLabel2 = new ui.CornerLabel('press [1]', -110, 350, Color4.White(), 12)
  breadLabel = new ui.UICounter(30, 0, 350, Color4.White(), 25, true)
  let breadIcon = new ui.MediumIcon('models/ui/manna_bread.png', -70, 345)

  let orbLabel2 = new ui.CornerLabel('press [2]', -110, 300, Color4.White(), 12)
  orbLabel = new ui.UICounter(30, 0, 300, Color4.White(), 25, true)
  let orbIcon = new ui.MediumIcon('models/ui/mana.png', -70, 295)

  expLabel = new ui.UICounter(0, 0, 250, Color4.White(), 25, true)
  let expIcon = new ui.MediumIcon('models/ui/exp.png', -70, 240)

  lvlLabel = new ui.UICounter(1, 0, 200, Color4.White(), 25, true)
  let lvlIcon = new ui.MediumIcon('models/ui/lv.png', -70, 200)
  
  //let largeImage = new ui.CenterImage('models/ui/manna_bread.png', 5)
}

export function displayMessage(t){
  ui.displayAnnouncement('t', 2, Color4.Green(), 20)
}


export function welcomeMessage(){
  let prompt = new ui.OkPrompt(
    'Hello and welcome to FarOut Mural!\n We\'ve created several Mural Puzzles for you to solve in order to win a prize.',
    () => {
      log(`accepted`)
    },
    'Ok',
    true
  )
}



export function rewardMessage( ){
  let prompt = new ui.OkPrompt(
    'Congratulations on solving all the puzzles!',
    () => {      
      log(`accepted`)
    },
    'Ok',
    true
  )
}

export function canPuzzleRewardMessage( ){
  let prompt = new ui.OkPrompt(
    'Congratulations you found all the cans!',
    () => {      
      log(`accepted`)

    },
    'Ok',
    true
  )
  // openExternalURL(this.canRewardURL)
}