import * as mob from './mob'
import * as game from './globalData'


@Component('Fireball')
export class fireBallC {

}
// Configuration
const MOVE_SPEED = 15
const ROT_SPEED = 15

let FIREBALLS = [];

// Intermediate variables
const player = Camera.instance

export class fireBall extends Entity {
  target: Entity
  damage = 20
  manaCost = 4
  constructor(playerPos, tar) {
    super()
    let t = new Transform()
    t.position.y = playerPos.y + .5
    t.position.x = playerPos.x
    t.position.z = playerPos.z

    engine.addEntity(this)
    this.addComponent(new GLTFShape('models/fireball.glb'))
    this.addComponent(t)
    this.addComponent(new fireBallC())
    this.target = tar
  }
}



 


// let mob2 = mob.spawnBlackDroid(
//   {
//     transform: new Transform({
//       position: new Vector3(10, 1.5, 16),
//       scale: new Vector3(.2, .2, .2),
//       rotation: Quaternion.Euler(0, 180, 0)
//     }),
//     speed : 2,
//     distanceLimit : 50, 
//     health : 100,
//     power: 10,
//     attackRange: 20,
//     chaseRange : 150
//   }
// )

class fireBallSystem implements ISystem {
  update(dt: number) {
    var fBALLS = engine.getComponentGroup(fireBallC).entities

    for (let fbb of fBALLS) {
      let fb = fbb as fireBall
      let target = fb.target as mob.MobDroid
      const transform = fb.getComponent(Transform)
      let tar = target.getComponent(Transform)    
      
      if( game.pData.mana < fb.manaCost ){
        engine.removeEntity(fb) 
        continue       
      }

      // Rotate to face the player
      const lookAtTarget = new Vector3(
        tar.position.x,
        transform.position.y,
        tar.position.z
      )
      const direction = lookAtTarget.subtract(transform.position)
      transform.rotation = Quaternion.Slerp(
        transform.rotation,
        Quaternion.LookRotation(direction),
        dt * ROT_SPEED
      )
      // Continue to move towards the tar until it is within 2m away
      const distance = Vector3.DistanceSquared(
        transform.position,
        tar.position
      ) // Check distance squared as it's more optimized
      if (distance >= 4) {
        // Note: Distance is squared so a value of 4 is when the zombie is standing 2m away
        //fb.walk()
        const forwardVector = Vector3.Forward().rotate(transform.rotation)
        const downVector = Vector3.Down().rotate(transform.rotation)
        
        const increment = forwardVector.scale(dt * MOVE_SPEED)
        const increment2 = downVector.scale(dt * 2)
        transform.translate(increment)
        transform.translate(increment2)
      } else {
        //fb.attack()
        //stops moving
        mob.gs.mySounds.hit2()
        target.receiveDamage(fb.damage)
        game.pData.useSkill(fb.manaCost);
        engine.removeEntity(fb)
      }
    }
  }
}

engine.addSystem(new fireBallSystem())
