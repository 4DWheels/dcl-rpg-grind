import * as gObjects from './game-obj'
import * as gSkills from './skill'
import * as mob from './mob'
import * as myUI from './ui'
import { scene } from './scene'
import { myCustomSounds } from './sound'
import * as game from './globalData'
import * as utils from '@dcl/ecs-scene-utils'


// Configuration
const Z_OFFSET = .5
const GROUND_HEIGHT = 1.2
const mySounds = new myCustomSounds()


// Intermediate variables
const player = Camera.instance

 myUI.buildUI()


 let FarOutMural = new gObjects.cMuralScene()

let puzzle1 = new gObjects.cPuzzlee(3,
  3,
  new Vector3(5, 3.5, 5), // position
  Quaternion.Euler(90, 0, 0),//rotation
  new Vector3(0.5, .5, .5), // scale
  "puzzle1",
  new Vector3(0, -0.1, -1), //plate position
  new Vector3(.1, 5.5, 4.2), //plate scale
  FarOutMural,
  2
);
puzzle1.setup()




// weapon 1
const weapon1 = new gObjects.Weapon1(
  new GLTFShape('models/fire_staff.glb'),
  new Transform({
    position: new Vector3(8, GROUND_HEIGHT, 8),
    scale: new Vector3(1.4, 1.4, 1.4)
  }),
  mySounds
)
weapon1.grab() 





// C O N T R O L S
const input = Input.instance

input.subscribe('BUTTON_DOWN', ActionButton.ACTION_3, false, (e) => {
  game.pData.useBread()
})

input.subscribe('BUTTON_DOWN', ActionButton.ACTION_4, false, (e) => {
  game.pData.useOrb()
})

// input.subscribe('BUTTON_DOWN', ActionButton.PRIMARY, false, (e) => {
//   const transform = weapon1.getComponent(Transform)
//   if (!weapon1.isGrabbed) {   
//     weapon1.grab()    
//   } else {
//     weapon1.putDown()
//   }
// })

// let t = new Transform(weapon1.getComponent(Transform))
// t.position.y = 1

// let projectile = new gObjects.fireBall( t )

// projectile.addComponentOrReplace(
//   new utils.MoveTransformComponent(
//     projectile.getComponent(Transform).position,
//     scene.pveAttackDroid2.entity.getComponent(Transform).position,
//     0.4,
//     () => { entityRemove(projectile)  }
//   )
// );



// Cast Skill if hit target
input.subscribe('BUTTON_DOWN', ActionButton.POINTER, true, (e) => {
  log(e.hit.entityId)

  if (engine.entities[e.hit.entityId] !== undefined) {
    let ent = engine.entities[e.hit.entityId]
    if(ent instanceof mob.MobDroid){
      let projectile = new gSkills.fireBall( player.position, engine.entities[e.hit.entityId])
    }

  }
})



export const mobLocs = []
mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
    transform: new Transform({
      position: new Vector3(13, 2.1, 16),
      scale: new Vector3(.2, .2, .2),
      rotation: Quaternion.Euler(0, 180, 0)
    }),
    speed : 2,
    distanceLimit : 50, 
    health : 400,
    power: 10,
    attackRange: 20,
    chaseRange : 150,
    attackSpeed: 1
}})


mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(18, 2.1, 10),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})


mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(27, 2.1, 10),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})


mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(27.5, 7, 27),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})


mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(13, 9.5, 27),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})


mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(15, 10.8, 3.78),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})



mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
  transform: new Transform({
    position: new Vector3(9.7, 2.3, 7.15),
    scale: new Vector3(.2, .2, .2),
    rotation: Quaternion.Euler(0, 180, 0)
  }),
  speed : 2,
  distanceLimit : 30, 
  health : 400,
  power: 10,
  attackRange: 20,
  chaseRange : 50,
  attackSpeed: 1
}})







// mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
//   transform: new Transform({
//     position: new Vector3(10, 2.1, 10),
//     scale: new Vector3(.2, .2, .2),
//     rotation: Quaternion.Euler(0, 180, 0)
//   }),
//   speed : 2,
//   distanceLimit : 50, 
//   health : 100,
//   power: 10,
//   attackRange: 20,
//   chaseRange : 150,
//   attackSpeed: .5  
  
// }})


// mobLocs.push({ isAlive: false, Timer: 10, entobj: undefined, config: {
//     transform: new Transform({
//       position: new Vector3(6, 1.5, 16),
//       scale: new Vector3(.2, .2, .2),
//       rotation: Quaternion.Euler(0, 180, 0)
//     }),
//     speed : 2,
//     distanceLimit : 50, 
//     health : 100,
//     power: 10,
//     attackRange: 20,
//     chaseRange : 150,
//     attackSpeed: .5
//   }})



 

class mobSpawner implements ISystem {
  update(dt: number) {
    //log(mobLocs)
    for(let mobLoc of mobLocs ){
      
      if(typeof mobLoc.entobj == "undefined" || engine.entities[mobLoc.entobj.uuid] == undefined){      
        mobLoc.entobj = mob.spawnBlackDroid(mobLoc.config)
        
        //log(mobLoc.entobj.uuid)
      } 

      // if(engine.entities[mobLoc.entobj.uuid] == undefined){      
      //   mobLoc.entobj.respawn()
      // } 
        
          
    }
  }
}

engine.addSystem(new mobSpawner())


function entityRemove(e){
  engine.removeEntity(e)
}