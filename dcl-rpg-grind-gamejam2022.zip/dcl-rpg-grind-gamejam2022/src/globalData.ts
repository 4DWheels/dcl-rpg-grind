import * as gObjects from './game-obj'
import * as myUI from './ui'

export const pData = new gObjects.playerData()




class uiUpdateData implements ISystem {
    update(dt: number) {
        myUI.HPBar.set(pData.health / 100)
        myUI.MPBar.set(pData.mana / 100)
        myUI.breadLabel.set(pData.breadCount)
        myUI.orbLabel.set(pData.orbCount)
        myUI.expLabel.set(pData.exp)
        myUI.lvlLabel.set(pData.lvl)
        myUI.killCountLabel.set(pData.killCount)

        
    }
  }
  
  engine.addSystem(new uiUpdateData())

