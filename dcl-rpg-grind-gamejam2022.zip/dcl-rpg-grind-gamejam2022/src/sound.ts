

export class myCustomSounds {
    isGrabbed: boolean = false
    pickUpSound = new Entity()
    putDownSound = new Entity()
    droidHit = new Entity()
    droidHit2 = new Entity()


    constructor() {

        // PICKUP
        this.pickUpSound.addComponent(new AudioSource(new AudioClip('sounds/pickUp.mp3')))
        this.pickUpSound.addComponent(new Transform())
        engine.addEntity(this.pickUpSound)
        this.pickUpSound.setParent(Attachable.AVATAR)

        // PUTDOWN
        this.putDownSound.addComponent(new AudioSource(new AudioClip('sounds/putDown.mp3')))
        this.putDownSound.addComponent(new Transform())
        engine.addEntity(this.putDownSound)
        this.putDownSound.setParent(Attachable.AVATAR)

        // hit 1
        this.droidHit.addComponent(new AudioSource(new AudioClip('sounds/dark_droid_hit.mp3')))
        this.droidHit.addComponent(new Transform())
        engine.addEntity(this.droidHit)
        this.droidHit.setParent(Attachable.AVATAR)


         // hit 2
         this.droidHit2.addComponent(new AudioSource(new AudioClip('sounds/fireBalllllll.mp3')))
         this.droidHit2.addComponent(new Transform())
         engine.addEntity(this.droidHit2)
         this.droidHit2.setParent(Attachable.AVATAR)


       
    }

    weaponPickUp() {
        this.pickUpSound.getComponent(AudioSource).playOnce()
    }

    weaponPutDown() {
        this.putDownSound.getComponent(AudioSource).playOnce()
    }

    droidHitSound() {
        this.droidHit.getComponent(AudioSource).playOnce()
    }

    hit2() {
        this.droidHit2.getComponent(AudioSource).playOnce()
    }
}


export const mySounds = new myCustomSounds()