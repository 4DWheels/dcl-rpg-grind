import * as game from './globalData'
import * as gameSounds from './sound'

// Configuration
const MOVE_SPEED = 1
const ROT_SPEED = 2
export let gs =  gameSounds
const cubeEntity8material = new Material()
cubeEntity8material.albedoColor = new Color3(0, 1, 0.03786659)
cubeEntity8material.emissiveColor = new Color3(0, 0, 0)

let DROIDS = [];
@Component('droidC')
export class droidC {

}

// define custom component
@Component("timer")
export class Timer {
  totalTime: number
  timeLeft: number
  constructor(time: number) {
    this.totalTime = time
    this.timeLeft = time
  }
}

export class mobHealth extends Entity {
  health: number
  maxHealth: number
  barLengthMax = 6

  constructor(maxHealth: number) {
    super()

    engine.addEntity(this);
    this.maxHealth = maxHealth
    this.health = maxHealth;
    //this.addComponent(new BoxShape())
    // this.addComponent(transform)   

    const cubeEntity8transform = new Transform({
      position: new Vector3(0, 4, 0),
      rotation: Quaternion.Euler(0, 90, 0),
      scale: new Vector3(.5, .5, this.barLengthMax)
    })
    this.addComponentOrReplace(cubeEntity8transform)
    const cubeEntity8boxShape = new BoxShape()
    this.addComponentOrReplace(cubeEntity8boxShape)
    // const cubeEntity8material = new Material()
    // cubeEntity8material.albedoColor = new Color3(0, 1, 0.03786659)
    // cubeEntity8material.emissiveColor = new Color3(0, 0, 0)
    this.addComponentOrReplace(cubeEntity8material)
  }



  updateHealth(n) {
    let p = n / this.maxHealth
    let newBarLength = this.barLengthMax * p
    let en = this.addComponentOrReplace(new Transform({
      position: new Vector3(0, 4, 0),
      rotation: Quaternion.Euler(0, 90, 0),
      scale: new Vector3(.5, .5, newBarLength)
    })
    )
  }

}

export function spawnBlackDroid(config) {
  let mob = new MobDroid(
    new GLTFShape('models/dark_droid.glb'),
    new Transform({
      position: new Vector3(config.transform.position.x, config.transform.position.y, config.transform.position.z),
      scale: new Vector3(config.transform.scale.x, config.transform.scale.y, config.transform.scale.z),
      rotation: Quaternion.Euler(0, 180, 0)
    }),
    config.speed,
    config.distanceLimit,
    config.health,
    "SphereAction", // attackAnim SphereAction
    "dead.001", // deadAnim
    "walkAnim", //walkAnim,
    config.power,
    config.attackRange,
    config.chaseRange,
    config.attackSpeed
  )

  return mob
}

export function spawnGreenDroid(config) {
  let mob = new MobDroid(
    new GLTFShape('models/green_droid.glb'),
    new Transform(config.transform),
    config.speed,
    config.distanceLimit,
    config.health,
    "SphereAction", // attackAnim
    "deadAnim", // deadAnim
    "walkAnim", //walkAnim
    config.power,
    config.attackRange,
    config.chaseRange,
    config.attackSpeed
  )

  return mob
}

export class MobDroid extends Entity {

  incomingAttack = false
  moveSpeed
  rotSpeed
  distanceLimit
  attackRange
  chaseRange: number
  attackAnim: string
  deadAnim: string
  walkAnim: string
  healthBarEntity
  health = 100
  isDead = false
  power
  attackSpeed
  attackTimer
  origPosition
  chasePlayer = false
  backToOrigPos = false

  constructor(model: GLTFShape, transform: Transform, speed: number, distanceLimit: number, health: number, attackAnim, deadAnim, walkAnim, power, attackRange, chaseRange, attackSpeed) {
    super()
    engine.addEntity(this)

    this.moveSpeed = speed
    this.rotSpeed = speed * 2
    this.distanceLimit = distanceLimit
    this.attackAnim = attackAnim
    this.deadAnim = deadAnim
    this.walkAnim = walkAnim
    this.health = health
    this.power = power
    this.attackRange = attackRange
    this.chaseRange = chaseRange
    this.attackSpeed = attackSpeed
    this.attackTimer = attackSpeed
    
    this.origPosition = new Vector3(transform.position.x, transform.position.y, transform.position.z)

    this.addComponent(model)
    this.addComponent(transform)

    this.addComponent(new Animator())

    //attack
    this.getComponent(Animator).addClip(
      new AnimationState(this.attackAnim, { looping: true })
    )

    //dead
    this.getComponent(Animator).addClip(
      new AnimationState(this.deadAnim, { looping: false })
    )

    //walk
    this.getComponent(Animator).addClip(
      new AnimationState(this.walkAnim, { looping: true })
    )

    this.addComponent(new droidC())


    const healthbar = new mobHealth(this.health)
    healthbar.setParent(this)
    this.healthBarEntity = healthbar

  }

  // Play attacking animation
  attack() {
    this.getComponent(Animator).getClip(this.attackAnim).play()
  }

  // Play walking animation
  walk() {
    this.stopAnimations()
    this.getComponent(Animator).getClip(this.walkAnim).play()
  }

  // Play die animation
  die() {
    //this.stopAnimations()
    game.pData.killCount = game.pData.killCount + 1
    

    this.getComponent(Animator).getClip(this.deadAnim).play()
    this.addComponent(new Timer(8))
  }

  receiveDamage(n) {
    this.health = this.health - n
    if (this.health <= 0) {
      this.health = 0
      this.isDead = true
    }
    this.healthBarEntity.updateHealth(this.health)
  }

  destroyEntity() {    
    engine.removeEntity(this)
  }

  // Bug workaround: otherwise the next animation clip won't play
  stopAnimations() {
    this.getComponent(Animator).getClip(this.deadAnim).stop()
    this.getComponent(Animator).getClip(this.attackAnim).stop()
    this.getComponent(Animator).getClip(this.walkAnim).stop()
  }
}

// Intermediate variables
const player = Camera.instance


class mobAttack implements ISystem {
  update(dt: number) {
    var fDroids = engine.getComponentGroup(droidC).entities

    function lookToPlayer(mDroid) {
      let droidTransform = mDroid.getComponent(Transform)
      // Rotate to face the player
      const lookAtTarget = new Vector3(
        player.position.x,
        droidTransform.position.y,
        player.position.z
      )
      const direction = lookAtTarget.subtract(droidTransform.position)
      droidTransform.rotation = Quaternion.Slerp(
        droidTransform.rotation,
        Quaternion.LookRotation(direction),
        dt * mDroid.rotSpeed
      )
      // Rotate to face the player <end>
    }

    function lookToOrigPos(mDroid) {
      let droidTransform = mDroid.getComponent(Transform)
      let origPos = mDroid.origPosition

      // Rotate to face the player
      const lookAtTarget = new Vector3(
        origPos.x,
        droidTransform.position.y,
        origPos.z
      )
      const direction = lookAtTarget.subtract(droidTransform.position)
      droidTransform.rotation = Quaternion.Slerp(
        droidTransform.rotation,
        Quaternion.LookRotation(direction),
        dt * mDroid.rotSpeed
      )
      // Rotate to face the player <end>
    }

    function walk(mDroid) {
      mDroid.walk()
      let droidTransform = mDroid.getComponent(Transform)
      const forwardVector = Vector3.Forward().rotate(droidTransform.rotation)
      const increment = forwardVector.scale(dt * mDroid.moveSpeed)
      droidTransform.translate(increment)
    }

    for (let mmDroid of fDroids) {
      let mDroid = mmDroid as MobDroid
      const _mSpeed = mDroid.moveSpeed
      const _rSpeed = mDroid.rotSpeed
      const _dtStop = mDroid.attackRange
      const droidTransform = mDroid.getComponent(Transform)

      // Continue to move towards the player until it is within 2m away
      const distanceToPlayer = Vector3.DistanceSquared(
        droidTransform.position,
        player.position
      ) // Check distance squared as it's more optimized

      // Continue to move towards the player until it is within 2m away
      const droidDistanceToOrigPos = Vector3.DistanceSquared(
        droidTransform.position,
        mDroid.origPosition
      ) // Check distance squared as it's more optimized

      const playerDistanceToOrigPos = Vector3.DistanceSquared(
        mDroid.origPosition,
        player.position
      ) // Check distance squared as it's more optimized

      const isPlayerInsideChaseRange = playerDistanceToOrigPos <= mDroid.chaseRange

      if (droidDistanceToOrigPos >= mDroid.distanceLimit || (!isPlayerInsideChaseRange && droidDistanceToOrigPos > 1)) {
        mDroid.backToOrigPos = true
      }

      //DROID DEAD
      if (mDroid.isDead) {

        if (!mDroid.hasComponent(Timer)) {
          mDroid.die()
        }
        if (mDroid.hasComponent(Timer)) {
          let timer = mDroid.getComponent(Timer)
          if (timer.timeLeft > 0) {
            timer.timeLeft -= dt
          } else {
            timer.timeLeft = timer.totalTime
            // DO SOMETHING
            mDroid.destroyEntity()
          }
        }
        continue
      }



      //log(droidDistanceToOrigPos)
      if (mDroid.backToOrigPos) {
        lookToOrigPos(mDroid)
        walk(mDroid)
        if (droidDistanceToOrigPos < 1) {
          mDroid.backToOrigPos = false
        }
        continue
      }



      if (isPlayerInsideChaseRange) { //look and walk to player "Chase the player"
        mDroid.chasePlayer = true
        lookToPlayer(mDroid)
      } else {
        mDroid.chasePlayer = false
      }

      if (mDroid.chasePlayer) {
        if (distanceToPlayer >= mDroid.attackRange) { //is in Attack Range          
          walk(mDroid)
        }
        else {
          mDroid.attack()

          //apply attack speed
          if (mDroid.attackTimer > 0) {
            mDroid.attackTimer -= dt
          } else {
            mDroid.attackTimer = mDroid.attackSpeed
            // DO SOMETHING
            gameSounds.mySounds.droidHitSound()

            
            
            game.pData.receiveDamage(mDroid.power)    
          }
                
        }
      }
    }



  }
}



engine.addSystem(new mobAttack())
